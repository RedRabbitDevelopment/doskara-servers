
var http = require('http');
http.createServer(function(request, response) {
  response.writeHead(301, {'Location': 'http://www.doskara.com'});
  response.end();
}).listen(80);
